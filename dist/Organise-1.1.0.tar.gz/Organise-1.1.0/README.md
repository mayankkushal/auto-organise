# Auto Organise

 A little tool that helps you organise your directory into meaningful subdirectories.


## Installation

```
git clone https://github.com/mayankkushal/auto-organise.git
cd auto-organise
python setup.py install
```

or

`pip install Organise`

## Usage

`organise`

### Help
`organise --help`


For comprehensive details [Read the docs](https://mayankkushal.github.io/auto-organise/)
